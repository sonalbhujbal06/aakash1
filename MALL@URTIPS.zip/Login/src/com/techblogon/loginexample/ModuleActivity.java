package com.techblogon.loginexample;

import com.example.eventlist.AndroidListViewCursorAdaptorActivity;




import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.app.Activity;
import android.content.Intent;


public class ModuleActivity extends Activity {

	private Button button6;
	private Button button2;
	private Button button5;
	
	

    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_module);
	
		
		button6 = (Button)findViewById(R.id.button6);
		button2 = (Button)findViewById(R.id.button2);
		button5 = (Button)findViewById(R.id.buttonmalloffer);
	
	
		
		
	// Set On ClickListener
		 button6.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					Intent myIntent = new Intent(getApplicationContext(), AndroidListViewCursorAdaptorActivity.class);
				
					startActivity(myIntent); 
					
			}
});
		 button2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					Intent myIntent = new Intent(getApplicationContext(), TempdirActivity.class);
				
					startActivity(myIntent); 
					
			}
});
	
		 button5.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					// TODO Auto-generated method stub
					
					Intent myIntent = new Intent(getApplicationContext(), TempmallActivity.class);
				
					startActivity(myIntent); 
					
			}
});
		
		 
		 
		 
	

	
	
	
	}
}
	
	
	
	
	
	
	
