package com.techblogon.loginexample;

public class Directory {
  
 String place= null;
 String name = null;

  
 public String getPlace() {
  return place;
 }
 public void setPlace(String place) {
  this.place = place;
 }
 public String getName() {
  return name;
 }
 public void setName(String name) {
  this.name = name;
 }

 }
 
  
