package com.techblogon.loginexample;

 
public class Offers {
  
 String code = null;
 String name = null;
 String validity= null;
 String brand= null;
  
 public String getCode() {
  return code;
 }
 public void setCode(String code) {
  this.code = code;
 }
 public String getName() {
  return name;
 }
 public void setName(String name) {
  this.name = name;
 }
 public String getValidity() {
  return validity;
 }
 public void setValidity(String validity) {
  this.validity = validity;
 }
 public String getBrand() {
  return brand;
 }
 public void setBrand(String brand) {
  this.brand = brand;
 }
 
  
}