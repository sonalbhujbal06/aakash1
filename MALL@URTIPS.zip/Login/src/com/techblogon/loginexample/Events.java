package com.techblogon.loginexample;

public class Events {
  
 String code = null;
 String name = null;
 String date = null;
 String time = null;
 String Sponser = null;
 String venue =null;
  
 public String getCode() {
  return code;
 }
 public void setCode(String code) {
  this.code = code;
 }
 public String getName() {
  return name;
 }
 public void setName(String name) {
  this.name = name;
 }
 public String getDate() {
  return date;
 }
 public void setDate(String date) {
  this.date = date;
 }
 public String getTime() {
  return time;
 }
 public void setTime(String time) {
  this.time = time;
 }
 public String getSponser() {
	  return Sponser;
	 }
	 public void setRegion(String Sponser) {
	  this.Sponser = Sponser;
	 }
	 public String getVenue() {
		  return venue;
		 }
		 public void setvenue(String venue) {
		  this.venue= venue;
		 }
	  
  
}
